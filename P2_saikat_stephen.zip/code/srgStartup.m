function [ ] = startup()
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
run('vlf/toolbox/vl_setup');
vl_setup demo;
end

