function [ ] = startup()
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
run('vlfeat-0.9.18/toolbox/vl_setup');
vl_setup demo;
end

